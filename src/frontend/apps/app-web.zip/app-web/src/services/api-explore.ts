import type { ApiResponse, PagedRequest, PagedResult } from "@atlas/shared-react-core/types";
import { requestApi, toQuery } from "./api-core";

export type AiPluginType = 0 | 1;
export type AiPluginStatus = 0 | 1;
export type AiPluginSourceType = 0 | 1 | 2;
export type AiPluginAuthType = 0 | 1 | 2 | 3 | 4;

export interface AiPluginListItem {
  id: number;
  name: string;
  description?: string;
  icon?: string;
  category?: string;
  type: AiPluginType;
  sourceType: AiPluginSourceType;
  authType: AiPluginAuthType;
  status: AiPluginStatus;
  isLocked: boolean;
  createdAt: string;
  updatedAt?: string;
  publishedAt?: string;
}

export interface AiPluginBuiltInMetaItem {
  code: string;
  name: string;
  description: string;
  category: string;
  version: string;
  tags: string[];
}

export interface AiPluginApiItem {
  id: number;
  pluginId: number;
  name: string;
  description?: string;
  method: string;
  path: string;
  requestSchemaJson: string;
  responseSchemaJson: string;
  timeoutSeconds: number;
  isEnabled: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface AiPluginDetail extends AiPluginListItem {
  definitionJson: string;
  authConfigJson: string;
  toolSchemaJson: string;
  openApiSpecJson: string;
  apis: AiPluginApiItem[];
}

export interface AiPluginMutationRequest {
  name: string;
  description?: string;
  icon?: string;
  category?: string;
  type: AiPluginType;
  definitionJson?: string;
  sourceType: AiPluginSourceType;
  authType: AiPluginAuthType;
  authConfigJson?: string;
  toolSchemaJson?: string;
  openApiSpecJson?: string;
  workspaceId?: string;
}

export interface TemplateListItem {
  id: string;
  name: string;
  category: number;
  schemaJson: string;
  description: string;
  tags: string;
  isBuiltIn: boolean;
  version: string;
  createdAt: string;
  updatedAt: string;
}

export interface TemplateSearchResponse {
  pageIndex: number;
  pageSize: number;
  total: number;
  items: TemplateListItem[];
}

export interface AiSearchResultItem {
  resourceType: string;
  resourceId: number;
  title: string;
  description?: string;
  path: string;
  updatedAt?: string;
}

export interface AiRecentEditItem {
  id: number;
  resourceType: string;
  resourceId: number;
  title: string;
  path: string;
  updatedAt: string;
}

export interface AiSearchResponse {
  items: AiSearchResultItem[];
  recentEdits: AiRecentEditItem[];
}

export interface AiMarketplaceProductListItem {
  id: number;
  categoryId: number;
  categoryName: string;
  name: string;
  summary?: string;
  icon?: string;
  productType: number;
  status: number;
  version: string;
  downloadCount: number;
  favoriteCount: number;
  isFavorited: boolean;
  publishedAt?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface AiMarketplaceProductDetail extends AiMarketplaceProductListItem {
  description?: string;
  tags: string[];
  sourceResourceId?: number;
  publisherUserId: number;
}

export interface TemplateDetailItem {
  id: number;
  name: string;
  category: number;
  schemaJson: string;
  description: string;
  tags: string;
  isBuiltIn: boolean;
  version: string;
  createdAt: string;
  updatedAt: string;
}

export interface TemplateInstantiateResult {
  schemaJson: string;
}

export async function getAiPluginsPaged(
  request: PagedRequest,
  keyword?: string,
  workspaceId?: string
): Promise<PagedResult<AiPluginListItem>> {
  const response = await requestApi<ApiResponse<PagedResult<AiPluginListItem>>>(`/ai-plugins?${toQuery(request, {
    keyword,
    workspaceId
  })}`);
  if (!response.data) {
    throw new Error(response.message || "查询插件失败");
  }

  return response.data;
}

export async function getAiPluginById(id: number): Promise<AiPluginDetail> {
  const response = await requestApi<ApiResponse<AiPluginDetail>>(`/ai-plugins/${id}`);
  if (!response.data) {
    throw new Error(response.message || "查询插件详情失败");
  }

  return response.data;
}

export async function createAiPlugin(request: AiPluginMutationRequest): Promise<number> {
  const response = await requestApi<ApiResponse<{ id?: string; Id?: string }>>("/ai-plugins", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request)
  });
  const id = response.data?.id ?? response.data?.Id;
  if (!response.success || id === undefined || id === null) {
    throw new Error(response.message || "创建插件失败");
  }

  return Number(id);
}

export async function updateAiPlugin(id: number, request: AiPluginMutationRequest): Promise<void> {
  const response = await requestApi<ApiResponse<object>>(`/ai-plugins/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request)
  });
  if (!response.success) {
    throw new Error(response.message || "更新插件失败");
  }
}

export async function deleteAiPlugin(id: number): Promise<void> {
  const response = await requestApi<ApiResponse<object>>(`/ai-plugins/${id}`, {
    method: "DELETE"
  });
  if (!response.success) {
    throw new Error(response.message || "删除插件失败");
  }
}

export async function publishAiPlugin(id: number): Promise<void> {
  const response = await requestApi<ApiResponse<object>>(`/ai-plugins/${id}/publish`, {
    method: "POST"
  });
  if (!response.success) {
    throw new Error(response.message || "发布插件失败");
  }
}

export async function getAiPluginBuiltInMetadata(): Promise<AiPluginBuiltInMetaItem[]> {
  const response = await requestApi<ApiResponse<AiPluginBuiltInMetaItem[]>>("/ai-plugins/built-in-metadata");
  if (!response.data) {
    throw new Error(response.message || "查询插件内置元数据失败");
  }

  return response.data;
}

export async function getTemplatesPaged(
  request: PagedRequest,
  filters?: { keyword?: string; category?: number }
): Promise<TemplateSearchResponse> {
  const response = await requestApi<ApiResponse<{
    pageIndex: number;
    pageSize: number;
    total: number;
    items: TemplateListItem[];
  }>>(`/templates?${toQuery(request, {
    keyword: filters?.keyword,
    category: filters?.category !== undefined ? String(filters.category) : undefined
  })}`);

  if (!response.data) {
    throw new Error(response.message || "查询模板失败");
  }

  return {
    pageIndex: response.data.pageIndex,
    pageSize: response.data.pageSize,
    total: response.data.total,
    items: response.data.items
  };
}

export async function searchAi(keyword: string, limit = 20): Promise<AiSearchResponse> {
  const response = await requestApi<ApiResponse<AiSearchResponse>>(`/ai-search?${toQuery({ pageIndex: 1, pageSize: limit }, {
    keyword,
    limit: String(limit)
  })}`);
  if (!response.data) {
    throw new Error(response.message || "搜索失败");
  }

  return response.data;
}

export async function getRecentAiEdits(limit = 20): Promise<AiRecentEditItem[]> {
  const response = await requestApi<ApiResponse<AiRecentEditItem[]>>(`/ai-search/recent?limit=${limit}`);
  if (!response.data) {
    throw new Error(response.message || "查询最近编辑失败");
  }

  return response.data;
}

export async function getMarketplaceProductsPaged(
  request: PagedRequest,
  filters?: { keyword?: string; categoryId?: number; productType?: number; status?: number }
): Promise<PagedResult<AiMarketplaceProductListItem>> {
  const response = await requestApi<ApiResponse<PagedResult<AiMarketplaceProductListItem>>>(
    `/ai-marketplace/products?${toQuery(request, {
      keyword: filters?.keyword,
      categoryId: filters?.categoryId !== undefined ? String(filters.categoryId) : undefined,
      productType: filters?.productType !== undefined ? String(filters.productType) : undefined,
      status: filters?.status !== undefined ? String(filters.status) : undefined
    })}`
  );
  if (!response.data) {
    throw new Error(response.message || "查询市场商品失败");
  }

  return response.data;
}

export async function getMarketplaceProductById(id: number): Promise<AiMarketplaceProductDetail> {
  const response = await requestApi<ApiResponse<AiMarketplaceProductDetail>>(`/ai-marketplace/products/${id}`);
  if (!response.data) {
    throw new Error(response.message || "查询市场商品详情失败");
  }

  return response.data;
}

export async function favoriteMarketplaceProduct(id: number): Promise<void> {
  const response = await requestApi<ApiResponse<object>>(`/ai-marketplace/products/${id}/favorite`, {
    method: "POST"
  });
  if (!response.success) {
    throw new Error(response.message || "收藏市场商品失败");
  }
}

export async function unfavoriteMarketplaceProduct(id: number): Promise<void> {
  const response = await requestApi<ApiResponse<object>>(`/ai-marketplace/products/${id}/favorite`, {
    method: "DELETE"
  });
  if (!response.success) {
    throw new Error(response.message || "取消收藏市场商品失败");
  }
}

export async function markMarketplaceProductDownloaded(id: number): Promise<void> {
  const response = await requestApi<ApiResponse<object>>(`/ai-marketplace/products/${id}/download`, {
    method: "POST"
  });
  if (!response.success) {
    throw new Error(response.message || "记录市场商品下载失败");
  }
}

export async function publishMarketplaceProduct(id: number, version: string): Promise<void> {
  const response = await requestApi<ApiResponse<object>>(`/ai-marketplace/products/${id}/publish`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ version })
  });
  if (!response.success) {
    throw new Error(response.message || "发布市场商品失败");
  }
}

export async function getTemplateById(id: number): Promise<TemplateDetailItem> {
  const response = await requestApi<ApiResponse<TemplateDetailItem>>(`/templates/${id}`);
  if (!response.data) {
    throw new Error(response.message || "查询模板详情失败");
  }

  return response.data;
}

export async function instantiateTemplate(id: number): Promise<TemplateInstantiateResult> {
  const response = await requestApi<ApiResponse<{ schemaJson?: string; SchemaJson?: string }>>(`/templates/${id}/instantiate`, {
    method: "POST"
  });
  const schemaJson = response.data?.schemaJson ?? response.data?.SchemaJson;
  if (!response.success || !schemaJson) {
    throw new Error(response.message || "模板实例化失败");
  }

  return { schemaJson };
}
